//const apiKey = 'd9c2f57'; 
const apiKey = 'd9c2f57';

function searchMovie() {
  const movieInput = document.getElementById('movieInput').value;
  const url = `http://www.omdbapi.com/?apikey=${apiKey}&s=${movieInput}`;

  fetch(url)
    .then(response => response.json())
    .then(data => displayMovies(data.Search))
    .catch(error => console.log('Error:', error));
}

function displayMovies(movies) {
  const movieResults = document.getElementById('movieResults');
  movieResults.innerHTML = '';

  if (movies) {
    movies.forEach(movie => {
      const card = createMovieCard(movie);
      movieResults.appendChild(card);
    });
  } else {
    movieResults.innerHTML = 'Фильмы не найдены';
  }
}

function createMovieCard(movie) {
  const card = document.createElement('div');
  card.classList.add('card');
  card.innerHTML = `
    <img src="${movie.Poster}" alt="${movie.Title}">
    <p>${movie.Title}</p>
    <button class="addToFavorites">Добавить в избранное</button>
  `;

  card.querySelector('.addToFavorites').addEventListener('click', (event) => {
    event.stopPropagation(); // чтобы клик по кнопке не вызывал клик по карточке
    addToFavorites(movie);
  });

  card.addEventListener('click', () => showMovieDetails(movie.imdbID));

  return card;
}

function addToFavorites(movie) {
  const selectedMovie = movie.Title;
  let favorites = JSON.parse(localStorage.getItem('favorites')) || [];
  
  if (!favorites.includes(selectedMovie)) {
    favorites.push(selectedMovie);
    localStorage.setItem('favorites', JSON.stringify(favorites));
    alert('Фильм добавлен в избранное.');
  } else {
    alert('Фильм уже в избранном.');
  }
}

function showMovieDetails(imdbID) {
  const url = `http://www.omdbapi.com/?apikey=${apiKey}&i=${imdbID}`;

  fetch(url)
    .then(response => response.json())
    .then(movie => displayMovieDetails(movie))
    .catch(error => console.log('Error:', error));
}

function displayMovieDetails(movie) {
  const movieDetails = document.getElementById('movieDetails');
  movieDetails.innerHTML = '';

  const details = document.createElement('div');
  details.innerHTML = `
    <div class=par>
      <h2>${movie.Title}</h2>
      <img src="${movie.Poster}" alt="${movie.Title}">
      <p><strong>Год:</strong> ${movie.Year}</p>
      <p><strong>Жанр:</strong> ${movie.Genre}</p>
      <p><strong>Режиссер:</strong> ${movie.Director}</p>
      <p><strong>Актеры:</strong> ${movie.Actors}</p>
      <p><strong>Описание:</strong> ${movie.Plot}</p>
      <button class="addToFavorites">Добавить в избранное</button>
    </div>
  `;
  movieDetails.appendChild(details);

  const addToFavoritesButton = movieDetails.querySelector('.addToFavorites');
  addToFavoritesButton.addEventListener('click', () => addToFavorites(movie));
}