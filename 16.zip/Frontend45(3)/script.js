const surnameInput = document.querySelector("#surname");
const nameInput = document.querySelector("#Name");
const ageInput = document.querySelector("#Age");
const button = document.querySelector("#addbutton");
const result = document.querySelector(".list");

let studentsList = [];

button.addEventListener("click", addStudent);

function addStudent() {
  let student = [];

  student.surname = surnameInput.value;
  student.name = nameInput.value;
  student.age = ageInput.value;

  studentsList.push(student);

  renderStudentList();
}

function renderStudentList() {
  let resultHTML = "";

  for (let i = 0; i < studentsList.length; i++) {
    let eachStudent = studentsList[i];
    resultHTML = `<li class="eachStudent">${eachStudent.surname} ${eachStudent.name} ${eachStudent.age}</li>`;
  }

  result.innerHTML += resultHTML;

  surnameInput.value = ""
  nameInput.value = ""
  ageInput.value = ""
}