let num1 = Number(prompt('Введите первое число: '));
let operation = prompt("Введите действие: + | - | * | /");
let num2 = +prompt('Введите первое число: ');

if (operation === "+") {
    alert(`Результат: ${num1 + num2}`)
} else if (operation === "-") {
    alert(`Результат: ${num1 - num2}`)
} else if (operation === "*") {
    alert(`Результат: ${num1 * num2}`)
} else if (operation === "/") {
    alert(`Результат: ${num1 / num2}`)
} 