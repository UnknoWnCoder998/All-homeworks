//Data 
let goalList = []
let goalId = 0
let currentGoal 
//Elements 
let goalTitleInput = document.getElementById('goal-title')
let goalDescInput = document.getElementById('goal-description')
let goalDueDateInput = document.getElementById('due-date')

let goalCreateForm = document.getElementById('goal-form')
let goalEditForm = document.getElementById("goal-edit=form")

let addedGoals = document.getElementById('goals')

let goalEditTitle = document.getElementById("goal-edit-titl")
let goalEditDiscription = document.getElementById("goal-edit-discription0")
let goalEditDate = document.getElementById("goal-edit-date")

//Event listeners
goalCreateForm.addEventListener('submit', function(event){
    event.preventDefault() //preventing site from reloading

    let data = {}
    data.goalTitle = goalTitleInput.value
    data.goalDesc = goalDescInput.value
    data.goalDate = goalDueDateInput.value
    data.goalId = goalId++

    goalList.push(data);

    
    renderGoalList()
})


goalEditForm.addEventListener("submit", function(event){
    event.preventDefault(); 
    
    let currentGoalIdx = goalList.findIndex(goal => goal.goalId === currentGoal.goalId)
    
    goalList[currentGoalIdx] = {

    goalTitle: goalEditTitle.value,
    goalDiscription: goalEditDescription.value,
    goalDate: goalEditDate.value,
   
    }

    renderGoalList();

    currentGoal = null

    let editModal = document.querySelector('.overlay')
    editModal.classList.remove('open')
})



function renderGoalList() {
    let goalsHTML = '';

    for(let i = 0; i < goalList.length; i++) {
        let dataObj = goalList[i]

        goalsHTML += `
        <li >
            <h3>${dataObj.goalTitle}</h3>
            <p>${dataObj.goalDesc}</p>
            <p>Due Date: ${dataObj.goalDate}</p>
            <button data-id="${dataObj.goalId}" onclick="openModal(${dataObj.goalId})">Edit</button>
            <button data-id="${dataObj.goalId}" onclick="deleteGoal(${dataObj.goalId})">Delete</button>
        </li>`
    }

    addedGoals.innerHTML = goalsHTML
}

function deleteGoal() {
    goalList = goalList.filter(item => item.goalId !== currentItem.getAttribute('data-id'))
    renderGoalList()
}

function openModal(event) {
    let editModal = document.querySelector('.overlay')
    editModal.classList.add('open')

    const currentGoal = goalList.find(goal => goal.goalId === id)
   if (currentGoal){
    goalEditTitle.value = currentGoal.goalTitle
    goalEditDiscription.value = currentGoal.goalDescription
    goalEditDate.value = currentGoal.goalDate
   }

} 

function clearCreateGoalForm(){
    goalTitleInput.value = ""
    goalDescriptionInput.value = ""
    goalDateInput.value = ""
}